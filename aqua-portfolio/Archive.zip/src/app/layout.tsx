import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "Petr Kindlmann | QA-Minded Developer",
  description: "QA automation engineer and full-stack developer building fast, beautiful, and reliable web applications with AI. Specializing in Playwright, TypeScript, React, and test automation.",
  keywords: [
    "QA Engineer",
    "Test Automation", 
    "Playwright",
    "TypeScript",
    "React",
    "Next.js",
    "Web Development",
    "Software Testing",
    "Czech Republic"
  ],
  authors: [{ name: "Petr Kindlmann", url: "mailto:thepetr@gmail.com" }],
  creator: "Petr Kindlmann",
  openGraph: {
    type: "website",
    title: "Petr Kindlmann | QA-Minded Developer",
    description: "QA automation engineer building fast, reliable web applications with comprehensive testing and AI integration.",
    siteName: "Petr Kindlmann Portfolio",
    locale: "en_US",
    url: "https://petrkindlmann.dev",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Petr Kindlmann - QA-Minded Developer Portfolio"
      }
    ]
  },
  twitter: {
    card: "summary_large_image",
    title: "Petr Kindlmann | QA-Minded Developer",
    description: "QA automation engineer building fast, reliable web applications with comprehensive testing.",
    creator: "@petrkindlmann",
    images: ["/og-image.png"]
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 5,
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className={`${inter.variable} antialiased font-sans`}>
        {children}
      </body>
    </html>
  );
}
