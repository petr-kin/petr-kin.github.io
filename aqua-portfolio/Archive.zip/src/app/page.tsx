import AquaLayout from '@/components/AquaLayout'
import HeroWave from '@/components/HeroWave'
import SkillsMarquee from '@/components/sections/SkillsMarquee'
import FeaturedProjects from '@/components/sections/FeaturedProjects'
import QALab from '@/components/sections/QALab'
import FAQ from '@/components/sections/FAQ'
import Contact from '@/components/sections/Contact'
import ScrollProgress from '@/components/ScrollProgress'
import GlassNavigation from '@/components/GlassNavigation'
import SectionDividerWave from '@/components/SectionDividerWave'

export default function Home() {
  return (
    <AquaLayout>
      <ScrollProgress />
      <GlassNavigation />
      
      <section id="home">
        <HeroWave />
      </section>
      
      <SectionDividerWave />
      
      <section id="skills">
        <SkillsMarquee />
      </section>
      
      <SectionDividerWave direction="up" variant="teal" />
      
      <section id="projects">
        <FeaturedProjects />
      </section>
      
      <SectionDividerWave />
      
      <section id="qa-lab">
        <QALab />
      </section>
      
      <SectionDividerWave direction="up" variant="aqua" />
      
      <FAQ />
      
      <section id="contact">
        <Contact />
      </section>
    </AquaLayout>
  )
}
