'use client'

import { motion } from 'framer-motion'
import ProjectCard from '@/components/ProjectCard'
import projectsData from '@/data/projects.json'

export default function FeaturedProjects() {
  const featuredProjects = projectsData.filter(project => project.featured)

  return (
    <section id="projects" className="py-24 relative">
      <div className="mx-auto max-w-6xl px-6">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass-card text-sm font-medium text-primary mb-4">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Featured Work
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-ink-900 mb-4 font-display">
            Quality-First Development
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Projects that combine clean code, comprehensive testing, and beautiful user experiences.
            Each solution is built with automation and reliability at its core.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredProjects.map((project, index) => (
            <motion.div
              key={project.slug}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.1 
              }}
            >
              <ProjectCard
                title={project.title}
                summary={project.summary}
                tags={project.tags}
                media={project.media}
                mediaType={project.mediaType as 'image' | 'video'}
                links={project.links}
              />
            </motion.div>
          ))}
        </div>

        {/* View All Projects CTA */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <motion.a
            href="/projects"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full glass-card border border-aqua-200/50 text-primary hover:bg-aqua-50 transition-all duration-200 font-medium"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            View All Projects
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}