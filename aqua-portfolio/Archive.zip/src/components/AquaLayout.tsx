'use client'

import { ReactNode } from 'react'
import { motion } from 'framer-motion'
import ParticleCanvas from './ParticleCanvas'

interface AquaLayoutProps {
  children: ReactNode
}

export default function AquaLayout({ children }: AquaLayoutProps) {
  const navItems = [
    { href: '#home', label: 'Home' },
    { href: '#projects', label: 'Projects' },
    { href: '#about', label: 'About' },
    { href: '#contact', label: 'Contact' }
  ]

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Background layers */}
      <div className="fixed inset-0 -z-20">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-aqua-50 via-background to-aqua-100" />
        
        {/* Particle grid overlay */}
        <div className="absolute inset-0 particle-grid opacity-30" />
        
        {/* Floating aqua blobs */}
        <div className="absolute -left-20 -top-20 w-80 h-80 bg-aqua-300/20 blur-3xl rounded-full animate-blob" />
        <div className="absolute -right-20 top-20 w-96 h-96 bg-aqua-500/15 blur-3xl rounded-full animate-blob animation-delay-2000" />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-aqua-400/10 blur-3xl rounded-full animate-blob animation-delay-4000" />
      </div>

      {/* Particle canvas */}
      <ParticleCanvas 
        density={40} 
        color="rgba(75, 160, 255, 0.15)" 
        className="fixed inset-0 -z-10" 
      />

      {/* Navigation */}
      <motion.header 
        className="fixed top-0 w-full z-50 glass-nav"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <nav className="mx-auto max-w-6xl px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <motion.div
              className="text-2xl font-bold bg-aqua-gradient bg-clip-text text-transparent"
              whileHover={{ scale: 1.05 }}
              transition={{ type: 'spring', stiffness: 400, damping: 10 }}
            >
              PK
            </motion.div>

            {/* Navigation links */}
            <div className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <motion.a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors relative group"
                  whileHover={{ y: -2 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                >
                  {item.label}
                  <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-aqua-gradient group-hover:w-full transition-all duration-300 rounded-full" />
                </motion.a>
              ))}
            </div>

            {/* Mobile menu button - simplified for now */}
            <div className="md:hidden">
              <button className="p-2 text-muted-foreground hover:text-primary transition-colors">
                <svg width="24" height="24" fill="none" viewBox="0 0 24 24">
                  <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
              </button>
            </div>
          </div>
        </nav>
      </motion.header>

      {/* Main content */}
      <main className="relative">
        {children}
      </main>

      {/* Footer */}
      <footer className="relative border-t border-border/40 bg-background/80 backdrop-blur-sm">
        <div className="mx-auto max-w-6xl px-6 py-12">
          <div className="flex flex-col items-center gap-4 text-center">
            <div className="flex gap-6">
              {[
                { icon: 'GH', href: '#', label: 'GitHub' },
                { icon: 'LI', href: '#', label: 'LinkedIn' },
                { icon: 'TW', href: '#', label: 'Twitter' },
                { icon: 'CV', href: '#', label: 'Resume' }
              ].map((social) => (
                <motion.a
                  key={social.icon}
                  href={social.href}
                  className="w-10 h-10 rounded-xl glass-card flex items-center justify-center text-xs font-semibold text-primary hover:text-primary-foreground hover:bg-primary/20 transition-all duration-200"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                >
                  {social.icon}
                </motion.a>
              ))}
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 Petr Kindlmann. QA-minded developer building fast, beautiful, and reliable web apps with AI.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}