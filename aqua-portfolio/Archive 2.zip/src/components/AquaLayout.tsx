'use client'

import { ReactNode, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import ParticleCanvas from './ParticleCanvas'

interface AquaLayoutProps {
  children: ReactNode
}

export default function AquaLayout({ children }: AquaLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  
  const navItems = [
    { href: '/', label: 'Home' },
    { href: '/expertise', label: 'Expertise' },
    { href: '/case-studies', label: 'Case Studies' },
    { href: '/blog', label: 'Blog' },
    { href: '/#contact', label: 'Contact' }
  ]

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Background layers */}
      <div className="fixed inset-0 -z-20">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-aqua-50 via-background to-aqua-100" />
        
        
        {/* Particle grid overlay */}
        <div className="absolute inset-0 particle-grid opacity-30" />
        
        {/* Floating aqua blobs */}
        <div className="absolute -left-20 -top-20 w-80 h-80 bg-aqua-300/20 blur-3xl rounded-full animate-blob" />
        <div className="absolute -right-20 top-20 w-96 h-96 bg-aqua-500/15 blur-3xl rounded-full animate-blob animation-delay-2000" />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-aqua-400/10 blur-3xl rounded-full animate-blob animation-delay-4000" />
      </div>

      {/* Particle canvas */}
      <ParticleCanvas 
        density={40} 
        color="rgba(75, 160, 255, 0.15)" 
        className="fixed inset-0 -z-10" 
      />

      {/* Navigation */}
      <motion.header 
        className="fixed top-0 w-full z-50 bg-white/70 backdrop-blur-xl border-b border-aqua-100/50 shadow-lg shadow-aqua-500/5"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <nav className="mx-auto max-w-6xl px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <motion.div
              className="flex items-center gap-2 group cursor-pointer"
              whileHover={{ scale: 1.05 }}
              transition={{ type: 'spring', stiffness: 400, damping: 10 }}
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-true-blue to-true-blue-600 flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                <span className="text-white font-bold text-lg">PK</span>
              </div>
              <div className="hidden sm:block text-sm text-midnight-100 group-hover:text-true-blue transition-colors">
                QA Engineer
              </div>
            </motion.div>

            {/* Navigation links */}
            <div className="hidden md:flex items-center gap-1 bg-slate-50/80 rounded-2xl p-1">
              {navItems.map((item, index) => (
                <motion.a
                  key={item.href}
                  href={item.href}
                  className="relative px-4 py-2 text-sm font-medium text-slate-700 hover:text-aqua-600 transition-all duration-300 rounded-xl group"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, type: 'spring', stiffness: 400, damping: 10 }}
                >
                  <motion.div
                    className="absolute inset-0 bg-white rounded-xl shadow-sm shadow-aqua-500/10 border border-aqua-100/50"
                    initial={{ scale: 0, opacity: 0 }}
                    whileHover={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.2 }}
                  />
                  <span className="relative z-10">{item.label}</span>
                  
                  {/* Active indicator dot */}
                  <motion.div
                    className="absolute -top-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-aqua-500 rounded-full opacity-0 group-hover:opacity-100"
                    initial={{ scale: 0 }}
                    whileHover={{ scale: 1 }}
                    transition={{ duration: 0.2 }}
                  />
                </motion.a>
              ))}
            </div>

            {/* CTA Button */}
            <motion.a
              href="/#contact"
              className="hidden lg:flex items-center gap-2 bg-sunny-yellow text-midnight px-6 py-2.5 rounded-xl font-medium text-sm hover:shadow-lg hover:shadow-sunny-yellow/25 hover:bg-sunny-yellow-400 transition-all duration-300"
              whileHover={{ scale: 1.02, y: -1 }}
              whileTap={{ scale: 0.98 }}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.3 }}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              Let&apos;s Talk
            </motion.a>

            {/* Mobile menu button */}
            <motion.button 
              className="md:hidden p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors"
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {!isMobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/>
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
                )}
              </svg>
            </motion.button>
          </div>
        </nav>
      </motion.header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            className="fixed inset-0 z-40 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-black/20 backdrop-blur-sm"
              onClick={() => setIsMobileMenuOpen(false)}
            />
            
            {/* Menu Panel */}
            <motion.div
              className="absolute top-20 left-4 right-4 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
            >
              <div className="p-6">
                {/* Navigation Links */}
                <div className="space-y-4">
                  {navItems.map((item, index) => (
                    <motion.a
                      key={item.href}
                      href={item.href}
                      className="flex items-center gap-4 p-3 rounded-xl hover:bg-aqua-50 transition-colors group"
                      onClick={() => setIsMobileMenuOpen(false)}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="w-2 h-2 bg-aqua-500 rounded-full group-hover:scale-125 transition-transform" />
                      <span className="text-midnight font-medium">{item.label}</span>
                    </motion.a>
                  ))}
                </div>

                {/* CTA Button */}
                <motion.a
                  href="/#contact"
                  className="mt-6 flex items-center justify-center gap-2 bg-sunny-yellow text-midnight px-6 py-3 rounded-xl font-medium hover:shadow-lg hover:shadow-sunny-yellow/25 hover:bg-sunny-yellow-400 transition-all duration-300"
                  onClick={() => setIsMobileMenuOpen(false)}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  Let&apos;s Talk
                </motion.a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <main className="relative">
        {children}
      </main>

      {/* Footer */}
      <footer className="relative border-t border-border/40 bg-background/80 backdrop-blur-sm">
        <div className="mx-auto max-w-6xl px-6 py-12">
          <div className="flex flex-col items-center gap-4 text-center">
            <div className="flex gap-6">
              {[
                { icon: 'GH', href: '#', label: 'GitHub' },
                { icon: 'LI', href: '#', label: 'LinkedIn' },
                { icon: 'TW', href: '#', label: 'Twitter' },
                { icon: 'CV', href: '#', label: 'Resume' }
              ].map((social) => (
                <motion.a
                  key={social.icon}
                  href={social.href}
                  className="w-10 h-10 rounded-xl glass-card flex items-center justify-center text-xs font-semibold text-primary hover:text-primary-foreground hover:bg-primary/20 transition-all duration-200"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 10 }}
                >
                  {social.icon}
                </motion.a>
              ))}
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 Petr Kindlmann. QA-minded developer building fast, beautiful, and reliable web apps with AI.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}